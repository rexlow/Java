abstract class Student {
  protected String name;
  protected boolean fullTimeStatus;

  abstract public void fees();
}
