abstract class GeometricFigure {
  protected double height;
  protected double width;
  protected double area;
  protected String type;

  abstract public void figureArea();
}
