public class Figure {
  public static void main(String[] args) {
    Square aSquare = new Square(2.5, 3.0);
    Triangle aTriangle = new Triangle(1.0, 3.5);

    aSquare.figureArea();
    aTriangle.figureArea();
  }
}
