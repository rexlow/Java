public class Loan {

  protected String date;
  protected int loanDuration;
  protected double oriLoan;
  protected double balanceDue;
}
