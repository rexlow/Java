interface LoanInterface {
  double CalculateFee();
}
