interface Sides {
  int printSide();
}
